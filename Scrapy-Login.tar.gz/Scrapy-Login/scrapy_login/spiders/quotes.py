from scrapy import Spider
from scrapy.http import FormRequest
from scrapy.loader import ItemLoader
from scrapy.utils.response import open_in_browser
from scrapy_login.items import ScrapyLoginItem


# спайдер с авторизацией
class QuotesSpider(Spider):
    name = 'quotes'
    start_urls = ('http://quotes.toscrape.com/login',)

    def parse(self, response):
        # получаем csrf токен
        token = response.xpath('//*[@name="csrf_token"]/@value').extract_first()
        # логинимся с токеном и паролем
        return FormRequest.from_response(response,
                                         formdata={'csrf_token': token,
                                                   'password': 'foobar',
                                                   'username': 'foobar'},
                                         callback=self.scrape_pages)

    # разбор ответа после авторизации
    def scrape_pages(self, response):
        # смотрим реультат авториации в браузере (приложен скрин)
        # open_in_browser(response)
        quotes = response.xpath("//div[@class='quote']/span[@class='text']")
        authors = response.xpath("//div[@class='quote']//small[@class='author']")
        urls = response.xpath("//div[@class='quote']/span/a/@href")
        for i, quote in enumerate(quotes):
            loader = ItemLoader(item=ScrapyLoginItem(), response=response)
            loader.add_value("quote", quote.root.text)
            loader.add_value("author", authors[i].root.text)
            loader.add_value("url", urls[i].root)
            yield loader.load_item()


        # Complete your code here to scrape the pages that you are redirected to after logging in

        # ....
        # ....
