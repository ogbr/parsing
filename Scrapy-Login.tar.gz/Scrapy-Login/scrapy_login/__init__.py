# Logging in with Scrapy
# Code written by GoTrained.com