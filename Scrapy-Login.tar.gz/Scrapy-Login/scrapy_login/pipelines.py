# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


class ScrapyLoginPipeline(object):
    def process_item(self, item, spider):
        print(f"Quote: {item['quote']}, author: {item['author'][0]}, url: {item['url']}")
        return item
